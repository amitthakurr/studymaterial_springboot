var express = require('express');
var router = express.Router();


var facebookEmployee = require('../controllers/facebookEmployee');



router.get('/test', facebookEmployee.facebookEmployee_name);


router.post('/create', facebookEmployee.facebookEmployee_name);

router.get('/:id', facebookEmployee.facebookEmployee_pass);

router.put('/:id/update', facebookEmployee.facebookEmployee_email);

router.delete('/:id/delete', facebookEmployee.facebookEmployee_address);


module.exports = router;