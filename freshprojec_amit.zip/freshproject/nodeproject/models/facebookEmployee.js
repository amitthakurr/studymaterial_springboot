var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var facebookEmployee = new Schema({
    name: {type: String, required: true, max: 100},
    pass: {type: Number, required: true},
    email: {type: String, required: true, max: 100},
    address: {type: Number, required: true}
});


// Export the model
module.exports = mongoose.model('facebookEmployee', facebookEmployee);