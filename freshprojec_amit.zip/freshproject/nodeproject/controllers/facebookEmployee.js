var details = require('../models/facebookEmployee');

//Simple version, without validation or sanitation
exports.test = function (req, res) {
    res.send('Greetings from the Facebook controller!');
};

exports.facebookEmployee_name = function (req, res) {
    details.find({}, function(err, fbUser){
        if(err){
            res.send("Its server error");
        }
        res.send(fbUser);
    })



    detail.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('detail submitted successfully')
    })
};

exports.facebookEmployee_pass = function (req, res) {
    detail.findById(req.params.id, function (err, detail) {
        if (err) return next(err);
        res.send(detail);
    })
};

exports.facebookEmployee_email = function (req, res) {
    detail.findByIdAndUpdate(req.params.id, {$set: req.body}, function (err, detail) {
        if (err) return next(err);
        res.send('detail udpated.');
    });
};

exports.facebookEmployee_address = function (req, res) {
    detail.findByIdAndRemove(req.params.id, function (err) {
        if (err) return next(err);
        res.send('Deleted successfully!');
    })
};