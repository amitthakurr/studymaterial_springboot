var http = require('http');
var fs = require('fs');
var mongo = require('mongodb');
var monk = require('monk');
var db = monk('localhost:27017/NIITB');
var collection = db.get('Employee');
var url = require('url');


http.createServer(function (req, res) {
    var ur = url.parse(req.url, true);

    var pathname = url.parse(req.url).pathname;
    console.log("Request for" + pathname + " recieved.");

    fs.readFile(pathname.substr(1), function (err, data) {
        if (err) {
            console.log(err.stack);
            res.writeHead(404, { "content-Type": "text/html" });
        } else {

            res.writeHead(200, { "Content-Type": "text/html" });

            var qr = ur.query;

            if (pathname == "/result.html") {
                var ob = JSON.stringify(qr);
                console.log(ob.length);
                if (ob.length > 2) {
                    var obj = JSON.parse(ob)
                    collection.insert({ email: obj.email, Name: obj.name, PASSWORD: obj.pass, ADDRESS: obj.address })
                    res.write("Name is-->" + obj.name);
                    res.write("Password is-->" + obj.pass);
                    res.write("address is-->" + obj.address);
                    res.write("email is-->" + obj.email);
                    res.write("<a href =login.html>Login</a>");

                }
            }

            if (pathname == "/details.html") {
                var ob = JSON.stringify(qr);
                console.log(ob);

                if (ob.length > 2) {
                    var obj = JSON.parse(ob)
                    collection.find({ "Name": obj.name, "PASSWORD": obj.pass }, function (err, data) {

                        if (err) throw err;
                        console.log("Welcome" + data)
                        db.close();
                    })

                    //   res.write("Name is-->" + obj.name);
                    // res.write("Password is-->" + obj.pass);

                }


            }
        }

        res.write(data.toString());
        res.end();
    });
}).listen(8000);

console.log('Server running');